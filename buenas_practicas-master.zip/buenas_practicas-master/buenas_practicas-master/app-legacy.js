// Calculadora
const displayElement = document.getElementById('display');
const buttons = document.querySelectorAll('.btn');
const clearButton = document.getElementById('clear');
const equalsButton = document.getElementById('equals');

let currentInput = '';
let lastOperator = '';
let shouldReset = false;

buttons.forEach(button => {
  button.addEventListener('click', () => {
    const value = button.getAttribute('data-value');
    if (shouldReset) {
      currentInput = '';
      shouldReset = false;
    }
    currentInput += value;
    displayElement.value = currentInput;
  });
});

clearButton.addEventListener('click', () => {
  currentInput = '';
  displayElement.value = '';
});

equalsButton.addEventListener('click', () => {
  try {
    const result = eval(currentInput);
    displayElement.value = result;
    shouldReset = true;
  } catch (error) {
    displayElement.value = 'Error';
  }
});

// To-Do List
const taskText = document.getElementById('taskText');
const addTaskButton = document.getElementById('addTask');
const taskList = document.getElementById('taskList');

addTaskButton.addEventListener('click', () => {
  const text = taskText.value.trim();
  if (text === '') {
    alert('Por favor ingresa una tarea');
    return;
  }

  const listItem = document.createElement('li');
  listItem.textContent = text;

  listItem.addEventListener('click', () => {
    listItem.classList.toggle('completed');
  });

  taskList.appendChild(listItem);
  taskText.value = '';
});
